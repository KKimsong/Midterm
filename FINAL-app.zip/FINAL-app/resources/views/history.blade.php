<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Information</title>
    <style>
        body {
            padding-top: 800px;
            font-family: Arial, sans-serif;
            justify-content: center;
            margin-top: 1200px;
            height: 100vh;
            background-color: #f5f5f5;
        }

        .container {
            margin-top: 120px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            width: 60%;
            margin-top: 20px;
        }

        .book {
            display: flex;
            margin-bottom: 40px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
        }

        .book img {
            width: 150px;
            height: 200px;
            margin-right: 20px;
            border-radius: 10px;
        }

        .book-info {
            width: calc(100% - 170px);
        }

        .book-info h2 {
            margin: 0 0 10px;
            font-size: 1.5em;
        }

        .book-info table {
            border-collapse: collapse;
            width: 100%;
        }

        .book-info table th,
        .book-info table td {
            text-align: left;
            padding: 8px;
            vertical-align: top;
        }

        .book-info table th {
            width: 30%;
            color: #555;
        }

        .book-info table td {
            width: 70%;
            color: #000;
        }

        .book-info table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .book-info .header {
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }

        .description {
            margin-top: 10px;
            color: #333;
        }
    </style>
</head>
@include('layout.layout')
@section('navigation')

<body>
    <div class="container">
        <div class="book">
            <img src="https://via.placeholder.com/150" alt="Thomas' Calculus">
            <div class="book-info">
                <h2>Thomas' Calculus</h2>
                <table>
                    <tr>
                        <th>Authors</th>
                        <td>
                            <ul>
                                <li>George B. Thomas</li>
                                <li>Maurice D. Weir</li>
                                <li>Joel R. Hass</li>
                            </ul>
                        </td>
                    </tr>
                    <tr>
                        <th>Year</th>
                        <td>2010</td>
                    </tr>
                    <tr>
                        <th>Publisher</th>
                        <td>Pearson Education</td>
                    </tr>
                    <tr>
                        <th>Categories</th>
                        <td>
                            <ul>
                                <li>Mathematics</li>
                                <li>Science</li>
                                <li>Analysis</li>
                            </ul>
                        </td>
                    </tr>
                    <tr>
                        <th>Language</th>
                        <td>English</td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="book">
            <img src="https://via.placeholder.com/150" alt="Atomic Habits">
            <div class="book-info">
                <h2>Atomic Habits</h2>
                <table>
                    <tr>
                        <th>Authors</th>
                        <td>James Clear</td>
                    </tr>
                    <tr>
                        <th>Year</th>
                        <td>2018</td>
                    </tr>
                    <tr>
                        <th>Publisher</th>
                        <td>Avery</td>
                    </tr>
                    <tr>
                        <th>Categories</th>
                        <td>Self Help</td>
                    </tr>
                    <tr>
                        <th>Language</th>
                        <td>English</td>
                    </tr>
                    <tr>
                        <th>Dewey ID</th>
                        <td>828</td>
                    </tr>
                    <tr>
                        <th>Shelf ID</th>
                        <td>828.jam</td>
                    </tr>
                    <tr>
                        <th>ISBN Number</th>
                        <td>978-0735211292</td>
                    </tr>
                </table>
                <div class="description">
                    Atomic Habits is a book by James Clear, one of the world’s leading experts on habit formation, that teaches readers how to form good habits, break bad ones, and master tiny behaviors that lead to remarkable results. It draws on the most proven ideas from biology, psychology, and neuroscience to create an easy-to-understand guide for making good habits inevitable and bad habits impossible.
                </div>
            </div>
        </div>

        <div class="book">
            <img src="https://via.placeholder.com/150" alt="It Ends with Us: A Novel">
            <div class="book-info">
                <h2>It Ends with Us: A Novel</h2>
                <table>
                    <tr>
                        <th>Authors</th>
                        <td>Colleen Hoover</td>
                    </tr>
                    <tr>
                        <th>Year</th>
                        <td>2016</td>
                    </tr>
                    <tr>
                        <th>Publisher</th>
                        <td>Atria (August 2, 2016)</td>
                    </tr>
                    <tr>
                        <th>Categories</th>
                        <td>Literary Fiction</td>
                    </tr>
                    <tr>
                        <th>Language</th>
                        <td>English</td>
                    </tr>
                    <tr>
                        <th>Dewey ID</th>
                        <td>822</td>
                    </tr>
                    <tr>
                        <th>Shelf ID</th>
                        <td>822.col</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

</body>
@include('footer.footer')
@section('content')

</html>