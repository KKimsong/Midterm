<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <!-- Style -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f5f5f5;
        }

        .container {
            margin-top: 120px;
            width: 30%;
            align-items: center;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .profile-pic {
            margin-right: 20px;
        }

        .profile-pic img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
        }

        .info {
            margin-top: 10px;
        }

        .info h2 {
            margin: 0;
            font-size: 1.5em;
        }

        .info table {
            margin-top: 10px;
            border-collapse: collapse;
            width: 100%;
        }

        .info table th,
        .info table td {
            text-align: left;
            padding: 8px;
        }

        .info table th {
            width: 30%;
            color: #555;
        }

        .info table td {
            width: 70%;
            color: #000;
        }

        .info table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .info .header {
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
    </style>
</head>
<!-- Navigation -->
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('navigation'); ?>

<body>

    <div class="container">
        <div class="profile-pic">
            <img src="https://via.placeholder.com/100" alt="Profile Picture">
        </div>
        <div class="info">
            <h2>User name</h2>
            <div class="header">Personal Information</div>
            <table>
                <tr>
                    <th>Title</th>
                    <td>-</td>
                </tr>
                <tr>
                    <th>Full Name</th>
                    <td>Kimsong Mak</td>
                </tr>
                <tr>
                    <th>Gender</th>
                    <td>Male</td>
                </tr>
                <tr>
                    <th>Date of Birth</th>
                    <td>-</td>
                </tr>
                <tr>
                    <th>Passport Number</th>
                    <td>-</td>
                </tr>
                <tr>
                    <th>National ID Number</th>
                    <td>011368534</td>
                </tr>
                <tr>
                    <th>Nationality</th>
                    <td>-</td>
                </tr>
            </table>
        </div>
    </div>

</body>
<!-- Footer -->
<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

</html><?php /**PATH /Users/kimsongmak/Desktop/FINAL-app/resources/views/profile.blade.php ENDPATH**/ ?>