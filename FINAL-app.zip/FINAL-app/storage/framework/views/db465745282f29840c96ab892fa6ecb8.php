<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Laravel</title>

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.bunny.net">
  <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>


  <!-- Styles -->
  <style>
        .body {
            font-family: Arial, sans-serif;
        }
        .section {
            margin: 20px;
        }
        .section h2 {
            color: green;
        }
        .books {
            display: flex;
            overflow-x: auto;
            scroll-behavior: smooth; /* Optional: Adds smooth scrolling effect */
            padding: 10px;
        }
        .books img {
            width: 200px;
            height: 250px;
            margin-right: 10px;
            flex: 0 0 auto; /* Ensures the images don't shrink and stay in a row */
            background-color: #E3E3E3;
        }
        .resources {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }
        .resources img {
            width: 100px;
            width: 150px;
            height: 200px;
            margin-right: 10px;
            flex: 0 0 auto; /* Ensures the images don't shrink and stay in a row */
            background-color: #E3E3E3;
        }
    </style>
</head>
  <!-- Navigation -->
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('navigation'); ?>

<body style="margin-top:50px;">
    <div class="section">
        <h2>New Books</h2>
        <p>Explore the newest and most recently added books</p>
        <div class="scroll-container">
            <button class="scroll-button left" onclick="scrollLeft('newBooks')">&#9664;</button>
            <div class="books" id="newBooks">
                <img src="" alt="New Book 1">
                <img src="" alt="New Book 2">
                <img src="" alt="New Book 3">
                <img src="new_book4.png" alt="New Book 4">
                <img src="new_book5.png" alt="New Book 5">
            </div>
            <button class="scroll-button right" onclick="scrollRight('newBooks')">&#9654;</button>
        </div>
    </div>

    <div class="section">
        <h2>Popular Books</h2>
        <p>Explore the most recently borrowed books</p>
        <div class="scroll-container">
            <button class="scroll-button left" onclick="scrollLeft('popularBooks')">&#9664;</button>
            <div class="books" id="popularBooks">
                <img src="design-for-writers-book-cover-tf-2-a-million-to-one.webp" alt="Popular Book 1">
                <img src="" alt="Popular Book 2">
                <img src="popular_book3.png" alt="Popular Book 3">
                <img src="popular_book4.png" alt="Popular Book 4">
                <img src="popular_book5.png" alt="Popular Book 5">
                <img src="popular_book1.png" alt="Popular Book 1">
                <img src="popular_book2.png" alt="Popular Book 2">
                <img src="popular_book3.png" alt="Popular Book 3">
                <img src="popular_book4.png" alt="Popular Book 4">
                <img src="popular_book5.png" alt="Popular Book 5">
            </div>
            <button class="scroll-button right" onclick="scrollRight('popularBooks')">&#9654;</button>
        </div>
    </div>

    <div class="section">
        <h2>External Resources</h2>
        <p>Explore the external resources</p>
        <div class="scroll-container">
            <button class="scroll-button left" onclick="scrollLeft('resource')">&#9664;</button>
            <div class="books" id="resource">
                <img src="" alt="Resources Book 1">
                <img src="" alt="Resources Book 2">
                <img src="" alt="Resources Book 3">
                <img src="" alt="ResourcesBook 4">
                <img src="" alt="Resources Book 5">
                <img src="" alt="Resources Book 1">
                <img src="" alt="Resources Book 2">
                <img src="" alt="Resources Book 3">
                <img src="" alt="Resources Book 4">
                <img src="" alt="Resources Book 5">
            </div>
            <button class="scroll-button right" onclick="scrollRight('resource')">&#9654;</button>
        </div>
    </div>

    <script>
        function scrollLeft(id) {
            const container = document.getElementById(id);
            container.scrollBy({ left: -200, behavior: 'smooth' });
        }

        function scrollRight(id) {
            const container = document.getElementById(id);
            container.scrollBy({ left: 200, behavior: 'smooth' });
        }
    </script>
  </body>
    <!-- Footer -->
<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
</html><?php /**PATH /Users/kimsongmak/Desktop/FINAL-app/resources/views/welcome.blade.php ENDPATH**/ ?>