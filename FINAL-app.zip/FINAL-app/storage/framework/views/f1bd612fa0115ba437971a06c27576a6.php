<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <!-- Style -->
<style>
    * {
        font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        box-sizing: border-box;
        padding: 0;
        margin: 0;
    }

    body {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background-color: #f0f0f0;
        padding: 20px;
    }

    form {
        width: 100%;
        max-width: 500px;
        padding: 30px;
        background-color: #fff;
        border-radius: 15px;
        box-shadow: rgba(21, 113, 204, 0.4) 0px 2px 4px, rgba(10, 121, 181, 0.3) 0px 7px 13px -3px, rgba(0, 135, 245, 0.2) 0px -3px 0px inset;
    }

    h1 {
        text-align: center;
    }

    p {
        text-align: center;
    }

    input[type=text],
    input[type=password] {
        display: block;
        border: 2px solid #ccc;
        width: 95%;
        padding: 10px;
        margin: 10px auto;
        border-radius: 5px;
    }

    hr {
        border: 1px solid #f1f1f1;
        margin-bottom: 25px;
    }

    button {
        float: right;
        background-color: #555;
        padding: 10px 15px;
        color: #fff;
        border-radius: 5px;
        margin-right: 10px;
        border: none;
    }

    button:hover {
        opacity: .7;
    }

    .cancelbtn {
        background-color: #f44336;
        border-radius: 10px;
    }

    .cancelbtn,
    .signupbtn {
        float: none;
        width: 100%;
        height: 40px;
        border-radius: 10px;
        margin: 5px 0;
    }

    .container {
        padding: 16px;
    }

    .clearfix::after {
        content: "";
        clear: both;
        display: table;
    }
</style>
</head>

<!-- Navigation -->
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('navigation'); ?>

<body>
    <!-- Content -->
    <div style="margin-top: 120px;">
        <form action="" method="POST" style="border:1px solid #ccc;">
            <div class="container">
                <h1 style="font-weight: bold; font-size:x-large;margin-bottom:10px;">Sign Up</h1>
                <p>Please fill in this form to create an account.</p>
                <hr>

                <label for="Username"><b>Username</b></label>
                <input type="text" placeholder="Enter Username" name="Enter Username" required>

                <label for="Email"><b>Email</b></label>
                <input type="text" placeholder="Enter Email" name="Enter Email" required>

                <label for="Password"><b>Password</b></label>
                <input type="Password" placeholder="Enter Password" name="Enter Password" required>

                <label for="Password"><b>Repeat Password</b></label>
                <input type="Password" placeholder="Repeat Password" name="Repeat Password" required>

                <label>
                    <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me</label>

                <p>By creating an account you agree to our <a href="" style="color:dodgerblue">Terms & Privacy</a>.</p>

                <div class="clearfix">
                    <button type="button" class="cancelbtn" style="background:#FE5E3C; ">Cancel</button>
                    <button type="submit" class="signupbtn" style=" background:#1AB7FC;">Sign Up</button>
                </div>
            </div>
        </form>

    </div>

</body>
<!-- Footer -->
<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

</html><?php /**PATH /Users/kimsongmak/Desktop/FINAL-app/resources/views/register.blade.php ENDPATH**/ ?>