<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Information</title>
    <!-- Style -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f5f5f5;
        }

        .container {
            width: 30%;
            align-items: center;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 120px;
        }

        .info {
            margin-top: 10px;
        }

        .info h2 {
            margin: 0;
            font-size: 1.5em;
        }

        .info table {
            margin-top: 10px;
            border-collapse: collapse;
            width: 100%;
        }

        .info table th,
        .info table td {
            text-align: left;
            padding: 8px;
        }

        .info table th {
            width: 30%;
            color: #555;
        }

        .info table td {
            width: 70%;
            color: #000;
        }

        .info table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .info .header {
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }

        .checkmark {
            color: green;
        }
    </style>
</head>
<!-- Navigation -->
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('navigation'); ?>

<body>

    <div class="container">
        <div class="info">
            <div class="header">User Information</div>
            <table>
                <tr>
                    <th>User ID</th>
                    <td>66247188</td>
                </tr>
                <tr>
                    <th>Username</th>
                    <td>kmak</td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td>kmak@paragoniu.edu.kh</td>
                </tr>
                <tr>
                    <th>Phone Number</th>
                    <td>077 767 689 <span class="checkmark">&#10004;</span></td>
                </tr>
                <tr>
                    <th>Recovery Email</th>
                    <td>kimsongmak@gmail.com <span class="checkmark">&#10004;</span></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>Active</td>
                </tr>
            </table>
        </div>
    </div>

</body>
<!-- Footer -->
<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

</html><?php /**PATH /Users/kimsongmak/Desktop/FINAL-app/resources/views/account.blade.php ENDPATH**/ ?>